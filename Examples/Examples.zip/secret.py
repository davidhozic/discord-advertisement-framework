"""
################################
@name: secrets
@info: This file is used to hide sensitive data like your toke. You can then (in the main file) import the secrets file and pass the token as 'secrets.C_TOKEN' for example.
################################
"""


C_TOKEN  = "Read README.md to find information about retreiving the token"

