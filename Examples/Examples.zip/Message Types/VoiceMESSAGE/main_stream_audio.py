from datetime import timedelta
import daf
from daf import discord



############################################################################################
#                               GUILD MESSAGES DEFINITION                                  #
############################################################################################

accounts = [
    daf.ACCOUNT(
        token="JJJKHSAJDHKJHDKJ",
        is_user=False,
        servers=[
            daf.USER(
                snowflake=123456789, # ID of server (guild) or a discord.Guild object
                messages=[         # List MESSAGE objects 
                    daf.VoiceMESSAGE(
                                    start_period=None,                    # If None, messages will be send on a fixed period (end period)
                                    end_period=timedelta(seconds=15),       # If start_period is None, it dictates the fixed sending period,
                                                                            # If start period is defined, it dictates the maximum limit of randomized period
                                    data=[daf.AUDIO("VoiceMessage.mp3")], # Data you want to sent to the function (Can be of types : str, embed, file, list of types to the left
                                    channels=[12323,2313],
                                    start_in=timedelta(seconds=0),        # Start sending now (True) or wait until period
                                    remove_after=None                     # Remove the message never or after n-times, after specific date or after timedelta
                                    ),  
                ],
                logging=True,       # Generate file log of sent messages (and failed attempts) for this user
                remove_after=None   # When to remove the guild and it's message from the shilling list
            )
        ]
    )
]

############################################################################################

daf.run(accounts=accounts)